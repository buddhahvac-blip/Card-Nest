import {NextResponse} from 'next/server';
import {PROMO_RESERVE_BPS,MAX_PROMO_SHARE_OF_ORDER_BPS} from '../../../lib/promotions';
export async function GET(){return NextResponse.json({mode:'launch-safe',reserveFundingBps:PROMO_RESERVE_BPS,maxBenefitShareOfOrderBps:MAX_PROMO_SHARE_OF_ORDER_BPS,principles:['earned-revenue-funded','budget-capped','per-user-limited','refund-reversible','human-approval-for-sensitive-changes']});}
