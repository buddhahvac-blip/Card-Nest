import { NextResponse } from 'next/server';
import { db } from '../../../../lib/db';
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){try{const {id}=await params;const rows=await db()`SELECT id,card_name,set_name,card_number,condition,description,image_url,price_cents,status FROM listings WHERE id=${id} AND status='active' LIMIT 1`;if(!rows.length)return NextResponse.json({error:'Listing not found'},{status:404});return NextResponse.json({listing:rows[0]});}catch{return NextResponse.json({error:'Database is not configured yet'},{status:503})}}
