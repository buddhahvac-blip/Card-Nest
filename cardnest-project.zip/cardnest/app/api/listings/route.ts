import { NextResponse } from 'next/server';
import { db } from '../../../lib/db';
export async function GET(){try{const rows=await db()`SELECT id, card_name, set_name, condition, price_cents, status, created_at FROM listings WHERE status='active' ORDER BY created_at DESC LIMIT 50`;return NextResponse.json({listings:rows})}catch{return NextResponse.json({listings:[],error:'Database is not configured yet'},{status:503})}}
