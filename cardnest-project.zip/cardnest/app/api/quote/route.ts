import { NextRequest,NextResponse } from 'next/server';
import { quoteOrder } from '../../../lib/rules';
export async function POST(req:NextRequest){try{const body=await req.json();const priceCents=Number(body.priceCents);return NextResponse.json(quoteOrder(priceCents));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400})}}
