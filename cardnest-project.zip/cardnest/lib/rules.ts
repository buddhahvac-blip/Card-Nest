export const PLATFORM_FEE_BPS = 800;
export const MIN_PRICE_CENTS = 100;
export const MAX_PRICE_CENTS = 250_000;

export function quoteOrder(priceCents:number){
  if(!Number.isInteger(priceCents)||priceCents<MIN_PRICE_CENTS||priceCents>MAX_PRICE_CENTS) throw new Error('Price outside marketplace limits');
  const platformFeeCents=Math.max(1,Math.round(priceCents*PLATFORM_FEE_BPS/10_000));
  return {amountCents:priceCents,platformFeeCents,sellerProceedsCents:priceCents-platformFeeCents};
}

export function normalizeCondition(value:string){
  const allowed=['Near Mint','Lightly Played','Moderately Played','Heavily Played','Damaged'];
  if(!allowed.includes(value)) throw new Error('Invalid card condition');
  return value;
}
