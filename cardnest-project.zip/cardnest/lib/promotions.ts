export const PROMO_RESERVE_BPS = 1500; // 15% of earned CardNest marketplace fees
export const MAX_PROMO_SHARE_OF_ORDER_BPS = 2000; // hard cap: promo benefit <= 20% of order

export type PromoKind = 'seller_fee_discount'|'buyer_credit'|'referral_credit'|'featured_listing';

export function promotionFundingFromFee(platformFeeCents:number){
  if(!Number.isInteger(platformFeeCents)||platformFeeCents<0) throw new Error('Invalid fee');
  return Math.floor(platformFeeCents*PROMO_RESERVE_BPS/10_000);
}

export function capPromotionBenefit(orderCents:number, requestedCents:number, reserveCents:number){
  if([orderCents,requestedCents,reserveCents].some(v=>!Number.isInteger(v)||v<0)) throw new Error('Invalid promotion values');
  const orderCap=Math.floor(orderCents*MAX_PROMO_SHARE_OF_ORDER_BPS/10_000);
  return Math.min(requestedCents,orderCap,reserveCents);
}

export function referralEligible(input:{buyerId:string;referrerId:string;completedOrders:number;refunded:boolean}){
  return input.buyerId!==input.referrerId && input.completedOrders===1 && !input.refunded;
}
