# CardNest

CardNest is a Next.js + TypeScript collectible-card marketplace foundation backed by Neon Postgres.

## Current build
- Marketplace, card detail, seller listing, checkout quote, dashboard, Trust & Safety
- Neon-backed listing APIs and deterministic transaction rules
- Three-agent review architecture: Market AI, Profit AI, Strategy AI (advisory only)
- Order, shipment/dispute-ready, audit, and AI-evaluation data model
- Founding Collector promotional engine with revenue-funded reserve, hard campaign/user caps, refund reversals, and anti-abuse foundations
- Rewards, marketplace standards, Terms draft, and Privacy draft pages
- Health and deployment-readiness foundations

## Neon target
Project: `muddy-waterfall-70532466`
Branch: `production`

`neon.ts` intentionally contains only `defineConfig({})` until Auth/Data API choices are explicitly deployed.

## Local setup
1. `npm install`
2. Copy `.env.example` to `.env.local`
3. Set `DATABASE_URL` locally; never commit it.
4. Review and authorize `db/schema.sql` before applying it to production.
5. `npm run dev`

## Launch gates
Before real transactions: managed authentication, marketplace payment provider + verified webhooks + connected seller payouts/KYC, image storage, rate limiting, abuse/fraud controls, shipping/disputes/refunds, final attorney-reviewed Terms/Privacy/marketplace policies, monitoring/backups, accessibility review, tax/business configuration, and end-to-end tests.

Promotions must remain budget-capped and funded from earned marketplace revenue. AI agents may recommend promotions but cannot move funds or bypass the promotion rules engine.
