CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS profiles (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), auth_user_id text UNIQUE NOT NULL, display_name text NOT NULL, avatar_url text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS listings (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), seller_id uuid NOT NULL REFERENCES profiles(id), card_name text NOT NULL, set_name text, card_number text, condition text NOT NULL CHECK(condition IN ('Near Mint','Lightly Played','Moderately Played','Heavily Played','Damaged')), description text, image_url text, price_cents integer NOT NULL CHECK(price_cents>0), status text NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','active','reserved','sold','removed')), created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS listings_marketplace_idx ON listings(status, created_at DESC);
CREATE TABLE IF NOT EXISTS orders (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), buyer_id uuid NOT NULL REFERENCES profiles(id), seller_id uuid NOT NULL REFERENCES profiles(id), listing_id uuid NOT NULL REFERENCES listings(id), amount_cents integer NOT NULL CHECK(amount_cents>0), platform_fee_cents integer NOT NULL CHECK(platform_fee_cents>=0), seller_proceeds_cents integer NOT NULL CHECK(seller_proceeds_cents>=0), payment_provider text, payment_reference text UNIQUE, status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid','shipped','completed','cancelled','refunded','disputed')), created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS agent_evaluations (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), order_id uuid REFERENCES orders(id), listing_id uuid REFERENCES listings(id), agent_name text NOT NULL CHECK(agent_name IN ('market','profit','strategy')), recommendation jsonb NOT NULL, decision text NOT NULL DEFAULT 'review', model_version text, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS audit_log (id bigserial PRIMARY KEY, actor_type text NOT NULL CHECK(actor_type IN ('user','admin','system','agent')), actor_id text, action text NOT NULL, entity_type text NOT NULL, entity_id text, details jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS audit_entity_idx ON audit_log(entity_type, entity_id, created_at DESC);

-- Promotion engine: budgets are funded from earned marketplace revenue, never unrestricted AI spend.
CREATE TABLE IF NOT EXISTS promotion_reserve (
  id boolean PRIMARY KEY DEFAULT true CHECK (id),
  available_cents bigint NOT NULL DEFAULT 0 CHECK (available_cents >= 0),
  lifetime_funded_cents bigint NOT NULL DEFAULT 0 CHECK (lifetime_funded_cents >= 0),
  lifetime_spent_cents bigint NOT NULL DEFAULT 0 CHECK (lifetime_spent_cents >= 0),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO promotion_reserve (id) VALUES (true) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS promotions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  description text,
  kind text NOT NULL CHECK(kind IN ('seller_fee_discount','buyer_credit','referral_credit','featured_listing')),
  status text NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','scheduled','active','paused','ended')),
  budget_cents bigint NOT NULL DEFAULT 0 CHECK(budget_cents >= 0),
  spent_cents bigint NOT NULL DEFAULT 0 CHECK(spent_cents >= 0 AND spent_cents <= budget_cents),
  value_bps integer CHECK(value_bps IS NULL OR (value_bps BETWEEN 0 AND 10000)),
  value_cents integer CHECK(value_cents IS NULL OR value_cents >= 0),
  per_user_limit integer NOT NULL DEFAULT 1 CHECK(per_user_limit > 0),
  starts_at timestamptz,
  ends_at timestamptz,
  rules jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK(ends_at IS NULL OR starts_at IS NULL OR ends_at > starts_at)
);
CREATE INDEX IF NOT EXISTS promotions_active_idx ON promotions(status, starts_at, ends_at);

CREATE TABLE IF NOT EXISTS promotion_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  promotion_id uuid NOT NULL REFERENCES promotions(id),
  profile_id uuid NOT NULL REFERENCES profiles(id),
  order_id uuid REFERENCES orders(id),
  benefit_cents integer NOT NULL CHECK(benefit_cents >= 0),
  status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','earned','reversed','expired')),
  fingerprint text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS promotion_redemptions_user_idx ON promotion_redemptions(profile_id, promotion_id, created_at DESC);
